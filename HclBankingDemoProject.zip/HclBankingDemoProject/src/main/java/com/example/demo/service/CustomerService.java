package com.example.demo.service;

/**
* The CustomerService class provides all operations related to which service customer has requested.
* 
* @author  Yokesh Kovi
* @version 1.0
* 
*/

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.example.demo.BankingApplication;
import com.example.demo.controller.CustomException;
import com.example.demo.model.Customer;
import com.example.demo.model.CustomerAccount;
import com.example.demo.model.Token;
import com.example.demo.repository.CustomerAccountRepository;
import com.example.demo.repository.CustomerRepository;

@Service
public class CustomerService {
	
	private static final Logger logger = LoggerFactory.getLogger(CustomerService.class);

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private CustomerAccountRepository customerAccountRepository;

	//Validate the customer  
	public boolean validateCustomer(String customer_id) {
		Customer findByUsername = customerRepository.findByUsername(customer_id);
		if (findByUsername == null) {
			throw new CustomException("Invalid Customer");
		} else {
			return true;
		}
	}

	//Based on the requested service we are generating tokens and sending to the queue.
	public String bankServices(String service, String customer_id, double amount) {
		boolean validateCustomer = validateCustomer(customer_id);
		if (validateCustomer) {
			//checking requested service is vaild or not
			String service_request = customerRepository.getAvailableServices(service);
			logger.info("Available service count.." + service_request);
			if (service_request == null) {
				throw new CustomException("Request Service is not available");
			} else {
            //if the requested service is deposit.
				if (service_request.equalsIgnoreCase("deposit")) {
					//Token is responsible for generating token
					GenerateToken gen_token = new GenerateToken();
					Token token = new Token();

					token.setCustomerId(customer_id);
					token.setTokenId(gen_token.generated_token());
					token.setAmount(amount);
					BankingApplication.depositQueue.add(token);

				} 
				//if the requested service is withdraw.
				else if (service_request.equalsIgnoreCase("withdraw")) {
					GenerateToken gen_token = new GenerateToken();
					Token token = new Token();

					token.setCustomerId(customer_id);
					token.setTokenId(gen_token.generated_token());
					token.setAmount(amount);
					BankingApplication.withdrawQueue.add(token);

				} else {
					//if the requested service is current balance.
					GenerateToken gen_token = new GenerateToken();
					Token token = new Token();

					token.setCustomerId(customer_id);
					token.setTokenId(gen_token.generated_token());
					token.setAmount(amount);
					BankingApplication.balanceQueue.add(token);

				}

			}
		}

		return null;

	}

	//Based on scheduler we are processing the from the queue
	@Scheduled(fixedRate = 1000)
	public  void start_operation() {
		while (true) {
			try {
				//if balanceQueue > 0
				if (BankingApplication.balanceQueue.size() > 0) {
					Token take = BankingApplication.balanceQueue.take();
					CustomerAccount customerAccount  = customerAccountRepository.findTopByCustomerIdOrderByIdDesc(take.getCustomerId());
				    logger.info("Current balance available :::::"+customerAccount.getBalanceAmount());
				}
				//if depositQueue > 0
				if (BankingApplication.depositQueue.size() > 0) {
					Token take = BankingApplication.depositQueue.take();
					CustomerAccount customerAccount = customerAccountRepository.findTopByCustomerIdOrderByIdDesc(take.getCustomerId());
					double availableAmount = customerAccount.getBalanceAmount();
					CustomerAccount account = new CustomerAccount();
					account.setCustomerId(take.getCustomerId());
					account.setTokenNo(take.getTokenId());
					account.setDepositAmount(take.getAmount());
					//Adding amount to the existing amount
					account.setBalanceAmount(availableAmount + take.getAmount());
					customerAccountRepository.save(account);
				}
				//if withdrawQueue > 0
				if (BankingApplication.withdrawQueue.size() > 0) {
					Token take = BankingApplication.withdrawQueue.take();
					CustomerAccount customerAccount = customerAccountRepository.findTopByCustomerIdOrderByIdDesc(take.getCustomerId());
					double availableAmount = customerAccount.getBalanceAmount();
					if (availableAmount >= take.getAmount()) {

						CustomerAccount account = new CustomerAccount();
						account.setCustomerId(take.getCustomerId());
						account.setTokenNo(take.getTokenId());
						account.setWithdrawAmount(take.getAmount());
						//seperate amount from actualAmount
						account.setBalanceAmount(availableAmount - take.getAmount());
						customerAccountRepository.save(account);
					} else {
						throw new CustomException("Requested amount is not available");
					}
				}

			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

}
