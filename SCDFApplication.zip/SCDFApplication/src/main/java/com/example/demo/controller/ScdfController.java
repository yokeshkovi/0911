package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Customer;
import com.example.demo.repository.CustomerRepository;

@RestController
@RequestMapping("/ScdfApp")
public class ScdfController {
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@PostMapping("/saveCustomer")
	public String saveCustomerData(@RequestBody Customer customer) {
		try {
			customerRepository.save(customer);
		}catch(Exception ex) {
			throw new CustomException("Exception occur while saving data");
		}
		return "Customer data inserted successfully";
	}
	
	@PostMapping("/getCustomer")
	public Customer getCustomerDetails(@RequestHeader("cid") int cid ) {
		Customer customer = null;
		try {
			customer = customerRepository.findByCid(cid);
			System.out.println("Customer:::::::::"+customer);
		}catch(Exception ex) {
			throw new CustomException("No data is available");
		}
		return customer;
	}
	
	@PostMapping("/updateCustomer")
	public Customer updateCustomerData(@RequestHeader("cid") int cid,@RequestHeader("address") String address) {
		Customer customer = null;
		try {
			customer = customerRepository.findByCid(cid);
			customer.setAddress(address);
			customerRepository.save(customer);
			System.out.println("Customer:::::::::"+customer);
		}catch(Exception ex) {
			throw new CustomException("Exception occur while updating data");
		}
		return customer;
	}
	
	@GetMapping("/deleteCustomer")
	public String deleteCustomerData(@RequestHeader("cid") int cid ) {
		try {
			customerRepository.deleteByCid(cid);
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
			//throw new CustomException("Exception occur while deleting data");
			
		}
		return "customer data deleted successfully";
	}

}
