package com.springboottest.springboottest.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboottest.springboottest.Model.Login;
import com.springboottest.springboottest.dao.LoginDAO;

@Service
public class LoginService {

	@Autowired
	private LoginDAO loginDAO;

	public List<Login> getDetails(){
		return loginDAO.getValues();
	}

	public List<Login> getLoginDetails(String email){
		return loginDAO.getLoginValues(email);
	}

	@Transactional
	public int getUpdateLoginValues(String email,String newemail){
		return loginDAO.getUpdateLoginValues(email,newemail);
	}
	
	@Transactional
	public int insertLoginDetails(List<Login> login){
		return loginDAO.insertLoginDetails(login);
	}
}
