package com.example.demo.config;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.util.List;

@Component
public class DBWriter implements ItemWriter<Employee> {

	@Autowired
    private EmployeeRepository employeeRepository;

	/*
	 * @Autowired public DBWriter (EmployeeRepository employeeRepository) {
	 * this.employeeRepository = employeeRepository; }
	 */

    @Override
    public void write(List<? extends Employee> employees) throws Exception{
			try { 
					employeeRepository.saveAll(employees);
		  }catch(Exception ex) {
			  System.out.println(ex.getMessage());
		  }
    }
    
}
