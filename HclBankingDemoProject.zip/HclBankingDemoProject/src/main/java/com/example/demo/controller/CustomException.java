package com.example.demo.controller;

/**
* The CustomException which is used to handle custom exceptions 
*
* @author  Yokesh Kovi
* @version 1.0
* @since   2021-02-16 
*/

public class CustomException extends RuntimeException{

	public CustomException(Exception exp){
		super(exp);
	}
	
   public CustomException(String exp){
	   super(exp);
		
	}
}
