package com.springboottest.springboottest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboottest.springboottest.Model.Login;
import com.springboottest.springboottest.service.LoginService;



@RestController
public class SpringBootController {
	
	@Autowired
	private LoginService loginService;
	
	@GetMapping("/test")
	public List<Login> message() {
		List<Login> data = loginService.getDetails();
		return data;
	}
	
	@GetMapping("/test/{email}")
	public List<Login> selectLogin(@PathVariable String email) {
		List<Login> data = loginService.getLoginDetails(email);
		return data;
	}
	
	@GetMapping("/test/{email}/{newemail}")
	public String selectLogin(@PathVariable String email,@PathVariable String newemail) {
		int data = loginService.getUpdateLoginValues(email,newemail);
		if(data == 0) {
			return "Login data not updated sucessfully";
		}else {
			return "Login data updated sucessfully";
		}
		
	}
	
	@PostMapping(value ="/insert",headers = "Accept=*/*")
	public int insertLogin(@RequestBody List<Login> login) {
		int data = loginService.insertLoginDetails(login);
		return data;
	}
	
}
