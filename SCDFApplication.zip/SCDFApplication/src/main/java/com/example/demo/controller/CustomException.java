package com.example.demo.controller;


public class CustomException extends RuntimeException{

	public CustomException(Exception exp){
		super(exp);
	}
	
   public CustomException(String exp){
	   super(exp);
		
	}
}
