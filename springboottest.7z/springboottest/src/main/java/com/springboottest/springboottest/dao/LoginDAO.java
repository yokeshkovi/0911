package com.springboottest.springboottest.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.springboottest.springboottest.Model.Login;

@Repository
public class LoginDAO {
	@PersistenceContext
	private EntityManager entityManager;

	public List<Login> getValues(){
		Query query =  entityManager.createNativeQuery("select * from login");
		return  query.getResultList();
		
	}
	
	public List<Login> getLoginValues(String email){
		Query query =  entityManager.createNativeQuery("select * from login where email='"+email+"'");
		return  query.getResultList();
		
	}
	
	
	public int getUpdateLoginValues(String email,String newemail){
		Query query =  entityManager.createNativeQuery("update  login set email='"+newemail+"' where email='"+email+"'");
		return  query.executeUpdate();
		
	}

	public int insertLoginDetails(List<Login> login){
		for(Login log : login) {
		Query query =  entityManager.createQuery("insert into login values('"+log.getEmail()+"','"+log.getPassword()+"')");
		return  query.executeUpdate();
		}
		return 0;
	}
}
