package com.example.demo.service;

/**
* The GenerateToken class generates a unique token.
* 
* @author  Yokesh Kovi
* @version 1.0
* 
*/

import java.util.UUID;

public class GenerateToken {
	
	public String generated_token() {
		
		return UUID.randomUUID().toString();
		
	}

}
