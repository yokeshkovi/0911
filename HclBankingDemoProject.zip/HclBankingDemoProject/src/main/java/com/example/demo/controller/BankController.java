package com.example.demo.controller;

import org.slf4j.Logger;

/**
* The BankController which acts as a RestController which can accept 
* the request from the client and provides the services.
*
* @author  Yokesh Kovi
* @version 1.0
* @since   2021-02-16 
*/

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.CustomerAccount;
import com.example.demo.repository.CustomerAccountRepository;
import com.example.demo.service.CustomerService;

@RestController
@RequestMapping("/BankingApp")
public class BankController {
	private static final Logger logger = LoggerFactory.getLogger(BankController.class);
	
	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private CustomerAccountRepository customerAccountRepository;
	
	/**
	 * Ex APIs - http://localhost:8080/BankingApp/bankServices/deposit/5000
	 *           http://localhost:9090/BankingApp/bankServices/withdraw/1000
	 *           http://localhost:9090/BankingApp/bankServices/currentbalance
	 * @param service - what type of service 
	 * @param amount - how much amount need to deposit or withdraw
	 * @param customer_id
	 * @return String
	 */
	
	@PostMapping("/bankServices/{service}/{amount}")
	public String bankServices(@PathVariable String service,@PathVariable double amount,@RequestHeader("customer_id") String customer_id) {
		logger.info("info logger...."+customer_id+" service.."+service+" amount.."+amount);
		String bankServices = customerService.bankServices(service,customer_id,amount);
		return bankServices;
	}
	
	/**
	 * This method accepts the review which is provided for the particular service by the customer.
	 * 
	 * 
	 */
	  @PostMapping("/bankServices/review") public String
	  updateReviewForRequestedService(@RequestBody String review,@RequestHeader("token") String token) {
	  
	  logger.info("Review....."+review+" token........."+token);
	  CustomerAccount account = customerAccountRepository.findByTokenNo(token);
	  account.setReview(review); 
	  customerAccountRepository.save(account);
	  
	  return "Thanks for your review.";
	  
	  }
	 
	 
}
