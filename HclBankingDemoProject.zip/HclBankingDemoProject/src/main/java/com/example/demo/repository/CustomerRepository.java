package com.example.demo.repository;

/**
* The CustomerRepository which can provides all operations of the customer.
* 
* @author  Yokesh Kovi
* @version 1.0
* 
*/

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer>{
	
	//Checking that the customer is valid
    public Customer findByUsername(String customer_id);
	
    //validating data from BankServices table whether the service is available or not
	@Query("SELECT services FROM BankServices where services =?1") 
	public String getAvailableServices(@Param("service") String service);
	
}
