package com.example.demo.model;

/**
* The Customer class maintains the credentials of the customers. 
*
* @author  Yokesh Kovi
* @version 1.0
* @since   2021-02-16 
*/

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer {
	
	
	@Id
	private int id;
	
	
	private String username;
	
	private String password;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Customer [username=" + username + ", password=" + password + "]";
	}
	
	

}
