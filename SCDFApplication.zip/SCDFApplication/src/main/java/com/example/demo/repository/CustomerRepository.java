package com.example.demo.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.model.Customer;

@Transactional
public interface CustomerRepository extends JpaRepository<Customer, Integer> {
	
	public Customer findByCid(int cid);
	
	public void deleteByCid(int cid);

}
