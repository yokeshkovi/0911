package com.example.demo.model;

/**
* The BankServices class have what type of services bank provide to the customer 
*
* @author  Yokesh Kovi
* @version 1.0
* @since   2021-02-16 
*/
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class BankServices {
	
	
	@Id
	private int id;
	
	private String services;

	
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getServices() {
		return services;
	}

	public void setServices(String services) {
		this.services = services;
	}
	
	

}
