package com.example.demo.config;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import com.example.demo.model.Employee;
import com.fasterxml.jackson.core.type.TypeReference;
import com.sun.el.parser.ParseException;


@Configuration
@EnableBatchProcessing
public class SpringBatchConfig {

	/*
	 * @Bean public Job job(JobBuilderFactory jobBuilderFactory, StepBuilderFactory
	 * stepBuilderFactory, ItemReader<Employee> itemReader, ItemProcessor<Employee,
	 * Employee> itemProcessor, ItemWriter<Employee> itemWriter ) {
	 * 
	 * Step step = stepBuilderFactory.get("ETL-file-load") .<Employee,
	 * Employee>chunk(100) .reader(itemReader) .processor(itemProcessor)
	 * .writer(itemWriter) .build();
	 * 
	 * 
	 * return jobBuilderFactory.get("ETL-Load") .start(step) .build(); }
	 */

	/*
	 * @Bean public FlatFileItemReader<Employee> itemReader() throws
	 * JsonParseException, JsonMappingException, IOException { ObjectMapper mapper =
	 * new ObjectMapper(); TypeReference<List<Employee>> typeReference = new
	 * TypeReference<List<Employee>>(){}; InputStream inputStream =
	 * TypeReference.class.getResourceAsStream("src/main/resources/Employee.json");
	 * FlatFileItemReader<Employee> emp = (FlatFileItemReader<Employee>)
	 * mapper.readValue(inputStream, typeReference); return emp; }
	 */
    
   /* @Bean
    public FlatFileItemReader<Employee> itemReader() {
    	 JSONParser jsonParser = new JSONParser();
    	 FlatFileItemReader<Employee> employeeList = null;
         
         try (FileReader reader = new FileReader("/src/main/resources/Employee.json"))
         {
             //Read JSON file
             Object obj = jsonParser.parse(reader);
  
              employeeList = (FlatFileItemReader<Employee>) obj;
             System.out.println(employeeList);
              
         } catch (Exception e) {
             e.printStackTrace();
         }
		return employeeList;  
     }
}*/
/*
 * private static void parseEmployeeObject(JSONObject employee) { //Get employee
 * object within list JSONObject employeeObject = (JSONObject)
 * employee.get("employee");
 * 
 * //Get employee first name String firstName = (String)
 * employeeObject.get("firstName"); System.out.println(firstName);
 * 
 * //Get employee last name String lastName = (String)
 * employeeObject.get("lastName"); System.out.println(lastName);
 * 
 * //Get employee website name String website = (String)
 * employeeObject.get("website"); System.out.println(website); } }
 */

	/*
	 * @Bean public LineMapper<Employee> lineMapper() {
	 * 
	 * DefaultLineMapper<Employee> defaultLineMapper = new DefaultLineMapper<>();
	 * DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
	 * 
	 * lineTokenizer.setDelimiter(","); lineTokenizer.setStrict(false);
	 * lineTokenizer.setNames("id", "name", "dept", "salary");
	 * 
	 * BeanWrapperFieldSetMapper<Employee> fieldSetMapper = new
	 * BeanWrapperFieldSetMapper<>(); fieldSetMapper.setTargetType(Employee.class);
	 * 
	 * defaultLineMapper.setLineTokenizer(lineTokenizer);
	 * defaultLineMapper.setFieldSetMapper(fieldSetMapper);
	 * 
	 * return defaultLineMapper; }
	 */

}