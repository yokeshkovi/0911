package com.example.demo.controller;

/**
* The BankApplicationException program used for handling exceptions
*
* @author  Yokesh Kovi
* @version 1.0
* @since   2021-02-16 
*/

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class BankApplicationException {
	
	@ExceptionHandler(CustomException.class)
	@ResponseBody
	public String commonError(CustomException exp) {
		
		return exp.getMessage();
		
	}

}
