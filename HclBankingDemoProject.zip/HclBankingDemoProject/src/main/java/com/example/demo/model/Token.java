package com.example.demo.model;

/**
* The Token class generates a unique token for each individual service for the customer.
* 
* @author  Yokesh Kovi
* @version 1.0
* 
*/
public class Token {
	
	private String customerId;
	
	private String tokenId;
	
	private double amount=0.0;

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Token [customerId=" + customerId + ", tokenId=" + tokenId + ", amount=" + amount + "]";
	}

	

}
