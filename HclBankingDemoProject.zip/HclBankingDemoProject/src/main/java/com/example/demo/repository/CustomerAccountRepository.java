package com.example.demo.repository;

/**
* The CustomerAccountRepository which can perform operations related to CustomerAccount.
* 
* @author  Yokesh Kovi
* @version 1.0
* 
*/

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.CustomerAccount;

public interface CustomerAccountRepository extends JpaRepository<CustomerAccount, Integer>{
	
	//Fetching data from CustomerAccount based on tokenNo
	public CustomerAccount findByTokenNo(String tokenNo); 
	
	//Fetching latest record of current balance from CustomerAccount based on customerId
	public CustomerAccount findTopByCustomerIdOrderByIdDesc(String customerId);

}
