package com.example.demo;

/**
* The BankingApplication program implements the services to the customer with in sequential order.
* Here basically three services provided(deposit, withdraw, check current balance of the customer)
*
* @author  Yokesh Kovi
* @version 1.0
* @since   2021-02-16 
*/

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.example.demo.controller.BankController;
import com.example.demo.model.Token;

@SpringBootApplication
@EnableScheduling
public class BankingApplication {
	
	private static final Logger logger = LoggerFactory.getLogger(BankingApplication.class);
	
	//Creating Queues for each individual service, so that we can maintain order of the services. 
	public static BlockingQueue<Token> depositQueue = new  LinkedBlockingQueue<>();
	public static BlockingQueue<Token> withdrawQueue = new  LinkedBlockingQueue<>();
	public static BlockingQueue<Token> balanceQueue = new  LinkedBlockingQueue<>();

	public static void main(String[] args) {
		SpringApplication.run(BankingApplication.class, args);
		logger.info("Spring Boot Start.....");
	}

}
