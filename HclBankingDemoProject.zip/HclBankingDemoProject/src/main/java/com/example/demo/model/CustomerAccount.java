package com.example.demo.model;

import java.util.Date;

/**
* The CustomerAccount class which can have all type of transactions  history 
* where we can have how much amount that customer deposit , withdraw amount, current balance.
*
* @author  Yokesh Kovi
* @version 1.0
* @since   2021-02-16 
*/

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="CustomerAccount")
public class CustomerAccount {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	private String customerId;
	 
	private String tokenNo;
	
    private double depositAmount;
    
    private double balanceAmount;
    
    private double withdrawAmount;
    
    private String review;
    
    private Date update_timestamp; 

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getTokenNo() {
		return tokenNo;
	}

	public void setTokenNo(String tokenNo) {
		this.tokenNo = tokenNo;
	}

	public double getDepositAmount() {
		return depositAmount;
	}

	public void setDepositAmount(double depositAmount) {
		this.depositAmount = depositAmount;
	}

	public double getBalanceAmount() {
		return balanceAmount;
	}

	public void setBalanceAmount(double balanceAmount) {
		this.balanceAmount = balanceAmount;
	}

	public double getWithdrawAmount() {
		return withdrawAmount;
	}

	public void setWithdrawAmount(double withdrawAmount) {
		this.withdrawAmount = withdrawAmount;
	}

	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}
	
	public Date getUpdate_timestamp() {
		return update_timestamp;
	}

	public void setUpdate_timestamp(Date update_timestamp) {
		this.update_timestamp = update_timestamp;
	}

	@Override
	public String toString() {
		return "CustomerAccount [id=" + id + ", customerId=" + customerId + ", tokenNo=" + tokenNo + ", depositAmount="
				+ depositAmount + ", balanceAmount=" + balanceAmount + ", withdrawAmount=" + withdrawAmount
				+ ", review=" + review + "]";
	}
	
}
