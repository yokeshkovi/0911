package com.example.RestController;

import java.net.URI;

import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

public class DataController {
	
	@RequestMapping(value = { "/", "/home" }, method = RequestMethod.GET)
	public String displayHomePage(Model model, HttpSession session)throws Exception // Declaring method for display home page
	{
		
		return "home"; // display page.
	}
}
