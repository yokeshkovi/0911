package com.springboottest.springboottest.dao;

import java.util.List;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

@Repository
public class LoginDAO {
	@PersistenceContext
	private EntityManager entityManager;

	public List<String> getValues(){
		Query query = (Query) entityManager.createNativeQuery("select * from login");
		return ((javax.persistence.Query) query).getResultList();
		
	}

}
