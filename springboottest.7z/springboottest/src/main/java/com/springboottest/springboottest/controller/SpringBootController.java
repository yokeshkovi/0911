package com.springboottest.springboottest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboottest.springboottest.service.LoginService;



@RestController
public class SpringBootController {
	
	/*@Autowired
	private LoginService loginService;
	*/
	@GetMapping("/test/{name}")
	public String message(@PathVariable String name) {
		
		/*List<String> data = loginService.getDetails();
		System.out.println(data.size());*/
		return name;
	}
	
}
