package com.example.demo.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.json.simple.parser.JSONParser;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.model.EmployeeList;
import com.example.demo.repository.EmployeeRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/loadData")
public class EmpController {
	
	@Autowired
	private EmployeeRepository employeeRepository;

	@GetMapping("/employee")
	public void readData() {
		
		JSONParser jsonParser = new JSONParser();
		File directoryPath = new File("C:/Users/sudhakarbusupati/Desktop/Employee Json/");
	     try { 
		//List of all files and directories
	      for(File filesList : directoryPath.listFiles())
	      
        {
	    	  if(filesList.isFile()) {
	    		  FileReader reader = new FileReader(filesList);
            //Read JSON file
        	Object obj = jsonParser.parse(reader);
        		ObjectMapper mapper = new ObjectMapper();
        		EmployeeList employeeList = mapper.readValue(obj.toString(), EmployeeList.class);
            System.out.println(employeeList);
            
           // boolean flag = this.validateData(employeeList);
           // if(flag)
             this.writeData(employeeList.getEmployee());
	    	  }
        }
	    	  } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	public boolean validateData(List<Employee> employee)  {
		JSONParser jsonParser = new JSONParser();
	   	 List<Employee> employeeList = null;
	   	 
		try (FileReader reader = new FileReader("/src/main/resources/fileValidate.json"))
        {
			Employee emp = (Employee)jsonParser.parse(reader);
			boolean recordFlag = true;
			 for(Employee e : employee) {
            if(!e.getName().matches(emp.getName())) {
            	return false;
            	
            }
			 }
			
			
        }catch(Exception ex) {
        	ex.printStackTrace();
        	
        }
		
		
		return false;
	}
	
	
		
	
    public void writeData(List<Employee> employee) {
    	
    	employeeRepository.saveAll(employee);
		
		
	}
	
	
	
}
